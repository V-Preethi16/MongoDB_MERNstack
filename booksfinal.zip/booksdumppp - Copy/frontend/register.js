// JavaScript for form validation
document.getElementById("register-form").addEventListener("submit", (e) => {
    e.preventDefault();
    alert("Registration Successful!");
});