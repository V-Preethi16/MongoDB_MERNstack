// JavaScript for order confirmation page (optional)
document.addEventListener("DOMContentLoaded", () => {
    console.log("Order confirmation page loaded");
});