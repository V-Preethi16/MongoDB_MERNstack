const bcrypt = require('bcryptjs');

class User {
  constructor(db) {
    this.collection = db.collection('users');
  }

  async createUser(username, password) {
    const hashedPassword = await bcrypt.hash(password, 10);
    return this.collection.insertOne({ username, password: hashedPassword });
  }

  async findUser(username) {
    return this.collection.findOne({ username });
  }

  async validatePassword(user, password) {
    return bcrypt.compare(password, user.password);
  }
}

module.exports = User;
