class Book {
    constructor(db) {
      this.collection = db.collection('books');
    }
  
    async addBook(bookName, author) {
      return this.collection.insertOne({ bookName, author });
    }
  
    async listBooks() {
      return this.collection.find().toArray();
    }
  
    async addUserBook(userId, bookId) {
      return this.collection.updateOne({ _id: bookId }, { $push: { readers: userId } });
    }
  }
  
  module.exports = Book;
  