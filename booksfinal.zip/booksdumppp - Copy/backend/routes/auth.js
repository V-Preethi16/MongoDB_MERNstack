const express = require('express');
const jwt = require('jsonwebtoken');
const client = require('../app');
const User = require('../models/User');
const router = express.Router();

const secret = 'supersecretkey';

router.post('/signup', async (req, res) => {
  const { username, password } = req.body;
  const db = client.db('appDatabase');
  const userModel = new User(db);

  try {
    const user = await userModel.createUser(username, password);
    res.status(201).json({ message: 'User created successfully' });
  } catch (err) {
    res.status(500).json({ error: 'Failed to create user' });
  }
});

router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const db = client.db('appDatabase');
  const userModel = new User(db);

  try {
    const user = await userModel.findUser(username);
    if (user && await userModel.validatePassword(user, password)) {
      const token = jwt.sign({ userId: user._id }, secret);
      res.json({ token });
    } else {
      res.status(401).json({ error: 'Invalid credentials' });
    }
  } catch (err) {
    res.status(500).json({ error: 'Login failed' });
  }
});

module.exports = router;
