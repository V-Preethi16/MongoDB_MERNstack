const express = require('express');
const client = require('../app');
const Book = require('../models/Book');
const router = express.Router();

router.post('/add', async (req, res) => {
  const { bookName, author } = req.body;
  const db = client.db('appDatabase');
  const bookModel = new Book(db);

  try {
    const book = await bookModel.addBook(bookName, author);
    res.status(201).json({ message: 'Book added successfully', book });
  } catch (err) {
    res.status(500).json({ error: 'Failed to add book' });
  }
});

router.get('/list', async (req, res) => {
  const db = client.db('appDatabase');
  const bookModel = new Book(db);

  try {
    const books = await bookModel.listBooks();
    res.json(books);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch books' });
  }
});

module.exports = router;
