require('dotenv').config();
const express = require('express');
const { MongoClient, ServerApiVersion } = require('mongodb');
const authRoutes = require('./routes/auth');
const bookRoutes = require('./routes/books');

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(express.json());

const mongodb_user = process.env.MONGODB_USERNAME;
const mongodb_password = process.env.MONGODB_PASSWORD;

const uri = `mongodb+srv://${mongodb_user}:${mongodb_password}@cluster0.ndghduc.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0`;
console.log({uri});
const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  }
});

async function connectDB() {
  try {
    await client.connect();
    console.log('Connected to MongoDB');
  } catch (err) {
    console.error(err);
  }
}

connectDB();

// Routes
app.use('/auth', authRoutes);
app.use('/books', bookRoutes);

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});

module.exports = client; // Export MongoDB client
